<!-- Footer -->
<footer class="text-center text-lg-start bg-light text-muted" style="bottom:0;">
    <!-- Copyright -->
    <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
        Ngô Quang Vinh © 2022 Copyright:
        <a class="text-reset fw-bold" href="https://thuemienbac.vn/">Đại lý Thuế Miền Bắc</a>
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->